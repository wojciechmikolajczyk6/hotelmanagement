<?php $__env->startSection('content'); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"> Wszystkie rezerwacje:
        <a href="/admin/booking/create" class="float-right btn btn-success btn-sm"> Dodaj nową rezerwację</a>
        </h6>
    </div>
    <div class="card-body">
        <?php if(Session::has('success')): ?>
            <p class="text-success"> <?php echo e(session('success')); ?></p>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100" cellspacing="0">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Klient</th>
                    <th>Numer pokoju</th>
                    <th>Typ pokoju</th>
                    <th>Data zameldowania</th>
                    <th>Data wymeldowania</th>
                    <th>Akcja</th>
                </tr>
                <tfoot>
                <tr>
                    <th>#</th>
                    <th>Klient</th>
                    <th>Numer pokoju</th>
                    <th>Typ pokoju</th>
                    <th>Data zameldowania</th>
                    <th>Data wymeldowania</th>
                    <th>akcja</th>
                </tr>
                </tfoot>
                <tbody>
                <tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($booking->id); ?></th>
                    <th><?php echo e($booking->customer->full_name); ?></th>
                    <th><?php echo e($booking->room->title); ?></th>
                    <th><?php echo e($booking->room->roomtype->title); ?></th>
                    <th><?php echo e($booking->checkin_date); ?></th>
                    <th><?php echo e($booking->checkout_date); ?></th>
                    <th><a href="/admin/booking/<?php echo e($booking->id); ?>/delete" onclick="return confirm('Jestes pewny ze chcesz usunac rezerwacje?')"><i class="fa fa-trash"</a> </th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </thead>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\hotel-management-application\resources\views/booking/index.blade.php ENDPATH**/ ?>