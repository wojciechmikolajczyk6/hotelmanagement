<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">Blank Page</h1>


        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e($data->title); ?>

                        <a href="/admin/rooms/" class="btn btn-success float-right">Wroc na poprzednia strone</a></h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">

                            <table class="table table-bordered">
                                <tr>
                                    <th>tytul</th>
                                    <td><?php echo e($data->title); ?></td>
                                </tr>
                                <tr>
                                    <th>detale pokoju</th>
                                    <td><?php echo e($data->details); ?></td>
                                </tr>
                                <tr>
                                    <td>Galeria</td>
                                    <td>
                                        <table class="mt-4"table table-bordered mt-4">
                                <tr>
                                    <?php $__currentLoopData = $data->roomimgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="imgcol<?php echo e($img->id); ?>"><img width="120px" height="120px" src="<?php echo e(asset('storage/'.$img->image_path)); ?>"/>

                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </table>
                                <tr>
                                    <th>cena za dobe</th>
                                    <td><?php echo e($data->price); ?></td>
                                </tr>
                            </table>

                    </div>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->





    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <!-- Bootstrap core JavaScript-->
    <script src="/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="/vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="/js/demo/datatables-demo.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\hotel-management-application\resources\views/rooms/show.blade.php ENDPATH**/ ?>