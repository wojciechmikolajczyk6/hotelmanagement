<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <p class="card-body">
            <p><div class="card-text">
                Płatność zakończyła się powodzeniem.
            </div></p>
        </div>
    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\hotel-management-application\resources\views/booking/success.blade.php ENDPATH**/ ?>