<?php

function sortowanie_liczb_pierwszych ($arr){
    $j=0;
    foreach ($arr as $number) {
        $isPrime = true;
        for($i = 2; $i <= sqrt($number); $i++)
        {
            if($number % $i == 0)
            {
                unset($arr[$j]);
            }
        }
        $j++;

    }
    krsort($arr);
    return ($arr);
}










function fibonacci($num){
    $sum=0;
    $first=1;$second=1;
    for($i=0;$i<$num;$i++){
        if($i<=1){
            $next=1;
        }  else  {
            $next=$first+$second;
            $first=$second;
            $second=$next;
        }
        $sum+=$next;
        echo  $next." , ";


    }
    echo "<br>";
    echo "Suma ciagu: $sum";
}

fibonacci(10);


$sentence= "hello";
echo $sentence;
echo str_contains('hello', $sentence)




?>
















<?php /**PATH C:\Users\asus\hotel-management-application\resources\views/egzaminPHP.blade.php ENDPATH**/ ?>