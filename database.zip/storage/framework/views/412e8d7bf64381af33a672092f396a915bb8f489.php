<?php $__env->startSection('content'); ?>

<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="/img/Abstract_Blue_Background.png" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
            <img src="/img/Abstract_Blue_Background.png" class="d-block w-100" alt="...">

        </div>
        <div class="carousel-item">
            <img src="/img/Abstract_Blue_Background.png" class="d-block w-100" alt="...">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>

    </button>
</div>




<div class="container my-4">
    <h1 class="text-center border-bottom">Usługi</h1>
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row my-4">
        <div class="col-md-4">
        <a href="/service/<?php echo e($service->id); ?>"><img src="<?php echo e(asset('storage/'.$service->photo)); ?>" width="100%" class="img-thumbnail" alt ="..."></a>
        </div>
        <div class="col-md-8">
            <h3><?php echo e($service->title); ?></h3>
            <p><?php echo e($service->desc); ?></p>
            <p>
                <a href="/service/<?php echo e($service->id); ?>" class="btn btn-sm btn-primary">więcej informacji</a>
            </p>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

















</div>



<div class="container my-4">
    <h1 class="text-center border-bottom">Galeria</h1>
    <div class="row my-4">
        <?php $__currentLoopData = $roomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 ">
            <div class="card">
                <h5 class="card-header text-center"><?php echo e($roomtype->title); ?></h5>
                <div class="card-body">
                    <?php $__currentLoopData = $roomtype->roomimgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>

                        <a href="<?php echo e(asset('storage/'.$img->image_path)); ?>" data-lightbox="<?php echo e($roomtype->id); ?>">
                            <?php if($index > 0): ?>
                            <img class="img-fluid hide" src="<?php echo e(asset('storage/'.$img->image_path)); ?>"/></a>
                            <?php else: ?>
                                <img class="img-fluid" src="<?php echo e(asset('storage/'.$img->image_path)); ?>"/></a>
                                <?php endif; ?>

                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\hotel-management-application\resources\views//index.blade.php ENDPATH**/ ?>