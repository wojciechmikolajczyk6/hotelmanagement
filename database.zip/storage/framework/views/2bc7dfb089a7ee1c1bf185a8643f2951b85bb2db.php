<?php $__env->startSection('content'); ?>

    <div class="container my-4">
        <h3 class="m-3">Logowanie</h3>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="text-primary text-danger"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
            <p class="text-primary text-center"><?php echo e(session('success')); ?></p>
        <?php endif; ?>
        <?php if(Session::has('fail')): ?>
            <p class="text-primary text-danger"><?php echo e(session('fail')); ?></p>
        <?php endif; ?>
        <form method="POST" action="customer/login">
            <?php echo csrf_field(); ?>
            <table class="table table-bordered">
                <tr>
                    <th>Email:<span> *</span></th>
                    <td><input required type="email" name="email" class="form-control"></td>
                </tr>
                <tr>
                    <th>Hasło:<span> *</span></th>
                    <td><input required type="password" name="password" class="form-control"></td>
                </tr>
                <tr>
                    <td colspan='2'><input  type="submit" class="btn btn-success"></td>
                </tr>
            </table>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\hotel-management-application\resources\views/loginCustomer.blade.php ENDPATH**/ ?>