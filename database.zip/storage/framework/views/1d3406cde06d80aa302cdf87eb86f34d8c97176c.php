<?php $__env->startSection('content'); ?>

    <div class="container my-4">
        <h3 class="m-3">Rejestracja</h3>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="text-primary text-danger"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
            <p class="text-primary text-center"><?php echo e(session('success')); ?></p>
        <?php endif; ?>
        <form method="POST" action="admin/customers">
            <?php echo csrf_field(); ?>
        <table class="table table-bordered">
        <tr>
            <th>Imie i nazwisko:<span> *</span></th>
            <td><input required type="text" name="full_name" class="form-control"></td>
        </tr>
            <tr>
                <th>Email:<span> *</span></th>
                <td><input required type="email" name="email" class="form-control"></td>
            </tr>
            <tr>
                <th>Hasło:<span> *</span></th>
                <td><input required type="password" name="password" class="form-control"></td>
            </tr>
            <tr>
                <th>Numer telefonu:<span> *</span></th>
                <td><input required type="number" name="phone" class="form-control"></td>
            </tr>
            <tr>
                <th>Adres:</th>
                <td><textarea name="address" class="form-control"></textarea></td>
            </tr>
            <tr>
                <input type="hidden" name="front" value="customer">
                <td colspan='2'><input  type="submit" class="btn btn-success"></td>
            </tr>
        </table>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\hotel-management-application\resources\views/register.blade.php ENDPATH**/ ?>