<?php $__env->startSection('content'); ?>

    <div class="container my-4">
        <h3 class="m-3"><?php echo e($service->title); ?></h3>
        <p><?php echo e($service->full_desc); ?></p>
        <p>Aktualnie nie ma mozliwosci zamowienia uslug na stronie internetowej, prosze udac sie do recepcji.</p>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\hotel-management-application\resources\views/serviceShow.blade.php ENDPATH**/ ?>