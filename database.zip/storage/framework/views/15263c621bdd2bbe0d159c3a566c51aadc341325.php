<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">Blank Page</h1>


        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Dodaj typ pokoju
                        <a href="/admin/rooms/" class="btn btn-success float-right">Wroc na poprzednia strone</a></h6>
                </div>
                <div class="card-body">
                    <?php if(Session::has('success')): ?>
                        <p class="text-primary text-center"><?php echo e(session('success')); ?></p>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <form method="post" enctype="multipart/form-data" action="/admin/rooms/<?php echo e($data->id); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <table class="table table-bordered">
                                <tr>
                                    <th>tytul</th>
                                    <td><input value="<?php echo e($data->title); ?>" type="text" name="title" class="form-control"/></td>
                                </tr>
                                <tr>
                                    <th>detale pokoju</th>
                                    <td><textarea  class="form-control" name="details"><?php echo e($data->details); ?></textarea></td>
                                </tr>
                                <tr>
                                    <td>Galeria</td>
                                    <td>
                                        <table class="mt-4"table table-bordered mt-4">
                                            <tr>
                                                <input type="file" multiple name="images[]" />
                                                <?php $__currentLoopData = $data->roomimgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="imgcol<?php echo e($img->id); ?>"><img width="120px" height="120px" src="<?php echo e(asset('storage/'.$img->image_path)); ?>"/>
    <p class="mt-2">
    <button type="button" onclick="return confirm('Jesteś pewny, że chcesz usunąć zdjęcie?')" class="mt-2 btn btn-danger delete-image" data-image-id="<?php echo e($img->id); ?>">Usuń zdjęcie</button>
     </p>
                                                    </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <th>cena za dobe</th>
                                    <td><input value="<?php echo e($data->price); ?>" type="number" name="price" class="form-control"/></td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <input name='submit' type="submit" class="btn btn-primary"/>
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->





    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $(".delete-image").on('click', function(){
            var _img_id=$(this).attr('data-image-id');
            var _vm=$(this);
            $.ajax({
                url:'<?php echo e(url('/admin/roomimage/delete')); ?>/' +_img_id,
                dataType: 'json',
                beforeSend:function(){
                    _vm.addClass('disabled');

                },
                success:function(res){
                    console.log(res);
                    if (res.bool==true){
                        $(".imgcol"+_img_id).remove();
                        _vm.removeClass('disabled');
                    }

                }

            });

        });
    });

</script>



















<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\hotel-management-application\resources\views/rooms/edit.blade.php ENDPATH**/ ?>