<?php

    function palindrom($word) {
        $rev = strrev($word);
        $new_str = str_replace(' ', '', $word);
        $new_str2 = str_replace(' ', '', $rev);

        if ((strtolower($new_str)) === strtolower($new_str2)) {
            echo "palindrom";
        } else {
            echo "to nie jest palindorm";
        }
    }
    palindrom("Aganaga");

    function anagram($a, $b) {
        if (count_chars($a, 1) == count_chars($b, 1)){
            return true;
        } else {
            return false;
        }
    }
function mediana($numbers) {
    $count = count($numbers);
    if ($count === 0)  return null;
    asort($numbers);
    $half = floor($count / 2);
    if ($count % 2) return $numbers[$half];
    return ($numbers[$half - 1] + $numbers[$half]) / 2.0;
}


$nums = array (1, 2, 7, 10, 15, 11);
    echo mediana($nums);

    function lowest_num($numbers) {
        $sorted_array = asort($numbers);
        return $sorted_array;
    }
    $number = array (5, 10, 1, 15);
    echo lowest_num($number);


function sorting($numbers) {
    sort($numbers);
    return $numbers;
}
$arr= [1, 10, 2, 4,6];
$sorted = sorting($arr);


$wysokosc = 10;
$ilosc_gwiazdek = 1;
$ilosc_spacji = $wysokosc-1;
echo "<br>";
for ($i=0; $i<$wysokosc; $i++){
    echo ".";
    for ($j=0; $j<$ilosc_spacji; $j++){
        echo "/";
    }
    for ($k=0; $k<$ilosc_gwiazdek; $k++){

        echo '*';
    }
    echo '<br>';
    $ilosc_gwiazdek+= 2;
    $ilosc_spacji-=1;

}
















function sortowanie_liczb_pierwszych ($arr){
    $j=0;
    foreach ($arr as $number) {
        $isPrime = true;
        for($i = 2; $i <= sqrt($number); $i++)
            {
                if($number % $i == 0)
                    {
                        unset($arr[$j]);
                    }
            }
        $j++;

    }
    krsort($arr);
    return ($arr);
}
$primeCheck = array(1, 100, 2,3,5,6,7,15,100);
$primeNum = sortowanie_liczb_pierwszych ($primeCheck);
$sortedNumbers = krsort($primeNum);
foreach ($primeNum as $primeNumber) {
    echo $primeNumber. "|";
}

function ocena_skoku ($arr){
    foreach ($arr as $ocena){
        if ($ocena >20 or $ocena <0){
            return "Ocena nie moze byc wieszka niz 20 albo mniejsza od 0";
        }
    }

}

echo ocena_skoku (array(15,100,2000));




//FIZZZBUZZZZZZ

$i=1;

for ($j=0; $j<100; $j++){
    $isPrime = true;
    for($k = 2; $k <= sqrt($i); $k++)
    {
        if($i % $k == 0)
        {
            $isPrime = false;
        }
    }
    if($isPrime == true)
    {
        echo "$i <b>Bingo</b> <br>";
    }
    if ($i % 3 === 0 and $i % 5 === 0){
        echo "$i FizzBuzz <br>";
    } elseif ( $i % 3 === 0){
        echo "$i Fizz <br>";
    } else {
        echo "$i Buzz <br>";
    }
    $i++;
}



function fibonacci($num){
    $sum=0;
    $first=0;$second=1;
    for($i=0;$i<$num;$i++){
        if($i<=1){
            $next=$i;
        }  else  {
            $next=$first+$second;
            $first=$second;
            $second=$next;
        }
        $sum+=$next;
        echo  $next." , ";


    }
    echo "<br>";
    echo "Suma ciagu: $sum";
}

fibonacci(5);






















 ?><?php /**PATH C:\Users\asus\hotel-management-application\resources\views/test.blade.php ENDPATH**/ ?>