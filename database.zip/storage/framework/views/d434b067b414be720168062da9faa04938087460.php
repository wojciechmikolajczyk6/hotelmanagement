<?php $__env->startSection('content'); ?>
    <?php if(Session::has('customerLogin')): ?>
    <div class="container my-4">
        <h3 class="m-3">Rezerwacja pokoju</h3>
        <div class="card-body">
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="text-primary text-danger"><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
                <p class="text-primary text-center"><?php echo e(session('success')); ?></p>
            <?php endif; ?>
            <div class="table-responsive">
                <form method="post" enctype="multipart/form-data" action="/admin/booking">
                    <?php echo csrf_field(); ?>
                    <table class="table table-bordered">
                        <tr>
                            <th>Data zameldowania <span>*</span></th>
                            <td><input type="date" name="checkin_date" class="form-control checkindate"/></td>
                        </tr>
                        <tr>
                            <th>Data wymeldowania <span>*</span></th>
                            <td><input type="date" name="checkout_date" class="form-control"/></td>
                        </tr>
                        <tr>
                            <th>Dostępne pokoje: <span>*</span></th>
                            <td>
                                <select name="room_id" class="form-control room-list">
                                    <option>--- Prosze wybrac date zameldowania ---</option>
                                </select>
                                <p>Cena: <span class="show-room-price">*</span></p>
                            </td>
                        </tr>
                        <tr>
                            <th>Liczba osób dorosłych <span>*</span></th>
                            <td><input type="number" name="adults" class="form-control"/></td>
                        </tr>
                        <tr>
                            <th>Liczba dzieci <span>*</span></th>
                            <td><input type="number" name="children" class="form-control"/></td>
                        </tr>
                        <tr>
                            <td colspan="4">
                                <input type="hidden" name="customer_id" value="<?php echo e((session('data')[0]->id)); ?>">
                                <input type="hidden" name="roomprice" class="room-price" value="" >
                                <input type="hidden" name="ref" value="frontbooking">
                                <input name='submit' type="submit" class="btn btn-primary"/>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>
    <?php else: ?>
    <p>Aby dokonac rezerwacji nalezy zalogowac sie na konto uzytkownika</p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $(".checkindate").on('blur', function(){
                var _checkindate=$(this).val();
                console.log(_checkindate);
                $.ajax({
                    url: "/admin/booking/available-rooms/"+_checkindate,
                    dataType: 'json',
                    beforeSend:function(){
                        $(".room-list").html('<option>--- Prosze wybrac date zameldowania ---</option>');

                    },
                    success:function (res){
                        var _html='';
                        $.each(res.data, function(index,row){
                            _html+='<option data-price="'+row.roomtype.price+'" value="'+row.room.id+'">'+row.room.title+' - '+row.roomtype.title+'</option>';
                        });
                        $(".room-list").html(_html);


                        var _price = $(".room-list").find('option:selected').attr('data-price');
                        $(".room-price").val(_price);
                        $(".show-room-price").text(_price);

                    }
                });

            });
            $(document).on("change", ".room-list", function(){
                var _price = $(this).find('option:selected').attr('data-price');
                $(".room-price").val(_price);
                $(".show-room-price").text(_price);
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\hotel-management-application\resources\views/booking-form.blade.php ENDPATH**/ ?>