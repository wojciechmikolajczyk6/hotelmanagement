<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">Blank Page</h1>


        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Edytuj dane klienta #<?php echo e($data->id); ?>

                        <a href="/admin/customers/" class="btn btn-success float-right">Wroc na poprzednia strone</a></h6>
                </div>
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="text-primary text-danger"><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if(Session::has('success')): ?>
                        <p class="text-primary text-center"><?php echo e(session('success')); ?></p>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <form method="post" enctype="multipart/form-data" action="/admin/customers/<?php echo e($data->id); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <table class="table table-bordered">
                                <tr>
                                    <th>Imie i nazwisko <span>*</span></th>
                                    <td><input value="<?php echo e($data->full_name); ?>"type="text" name="full_name" class="form-control"/></td>
                                </tr>
                                <tr>
                                    <th>Email <span>*</span></th>
                                    <td><input value="<?php echo e($data->email); ?>"type="email" name="email" class="form-control"/></td>
                                </tr>
                                <tr>
                                    <th>Numer telefonu <span>*</span></th>
                                    <td><input value="<?php echo e($data->phone); ?>" type="text" name="phone" class="form-control"/></td>
                                </tr>
                                <tr>
                                    <th>Zdjecie</th>
                                    <td><input value="<?php echo e($data->photo); ?>" type="file" name="photo"/>
                                        <input value="<?php echo e($data->photo); ?>" type="hidden" name="last_photo"/>
                                        <img src="<?php echo e(asset('storage/'.$data->photo)); ?>" width="120px" hight="120px" alt=""></td>
                                </tr>
                                <tr>
                                    <th>Adres</th>
                                    <td><textarea value="<?php echo e($data->address); ?>" class="form-control" name="address"></textarea></td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <input name='submit' type="submit" class="btn btn-primary"/>
                                    </td>
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->





    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <!-- Bootstrap core JavaScript-->
    <script src="/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="/vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="/js/demo/datatables-demo.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\hotel-management-application\resources\views/customers/edit.blade.php ENDPATH**/ ?>