@extends('frontlayout')

@section('content')
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <p class="card-body ">
        <p><div class="card-text border-bottom-info text-center my-5">
            Płatność zakończyła się niepowodzeniem, proszę spróbować ponownie.
        </div></p>
    </div>
    </div>
    <!-- /.container-fluid -->
@endsection
